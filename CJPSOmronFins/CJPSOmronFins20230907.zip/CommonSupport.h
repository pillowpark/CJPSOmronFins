



#ifndef __COMMON_SUPPORT_H__
#define __COMMON_SUPPORT_H__


VOID DebugPrint(const TCHAR* ptszFormat, ...);



#endif
//__COMMON_SUPPORT_H__